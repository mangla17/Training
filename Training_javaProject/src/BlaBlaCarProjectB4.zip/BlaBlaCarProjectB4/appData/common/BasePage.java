package BlaBlaCarProjectB4.appData.common;

public class BasePage {
	
	String locOkBtn= "//ok";
	
	public void clickMyOk(){
		
	}

}
