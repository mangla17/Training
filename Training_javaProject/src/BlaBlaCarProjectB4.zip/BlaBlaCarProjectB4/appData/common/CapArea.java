package BlaBlaCarProjectB4.appData.common;

public class CapArea extends BasePage{
	
	
	public void clickTabOptions(String tabName){
		//
	}
	
	

}
