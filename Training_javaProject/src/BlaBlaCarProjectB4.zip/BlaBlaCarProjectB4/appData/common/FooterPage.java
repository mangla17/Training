package BlaBlaCarProjectB4.appData.common;

public class FooterPage extends BasePage{

}
