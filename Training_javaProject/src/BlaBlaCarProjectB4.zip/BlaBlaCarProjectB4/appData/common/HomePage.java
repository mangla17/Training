package BlaBlaCarProjectB4.appData.common;

public class HomePage extends BasePage{

}
