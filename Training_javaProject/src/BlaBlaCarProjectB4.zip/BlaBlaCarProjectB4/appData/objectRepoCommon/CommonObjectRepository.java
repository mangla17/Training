package BlaBlaCarProjectB4.appData.objectRepoCommon;

public class CommonObjectRepository {
	
	
	public static String okButton ="";
	
	
	
	
	
	

}
