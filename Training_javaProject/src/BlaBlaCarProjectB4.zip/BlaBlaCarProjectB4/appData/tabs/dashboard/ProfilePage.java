package BlaBlaCarProjectB4.appData.tabs.dashboard;

public class ProfilePage extends BaseTabPage{

}
