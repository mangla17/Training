package BlaBlaCarProjectB4.appData.tabs.dashboard;

public class RidesOfferedPage extends BaseTabPage{

}
