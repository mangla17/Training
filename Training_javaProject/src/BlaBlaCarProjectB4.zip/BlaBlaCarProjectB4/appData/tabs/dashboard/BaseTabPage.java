package BlaBlaCarProjectB4.appData.tabs.dashboard;

import BlaBlaCarProjectB4.appData.common.BasePage;

public class BaseTabPage extends BasePage{

}
