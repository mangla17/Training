package BlaBlaCarProjectB4.appData.tabs.dashboard;

public class DashboardPage extends BaseTabPage{
	
	String locDashboardTab = "";
	String locEditYourProfileLink = "";
	String ViewYourPublicProfileLink= "";
	String locOkBtn= "//ok_1";
	
	
	public void clickDashboardTab(){
		//
	}
	
	public void clickEditYourProfileLink(){
		//
	}
	
	public void clickViewYourPublicProfileLink(){
		//
	}
	
	public boolean isDashboardTabPresent(){
		return false;
		//
	}
	
	public boolean isEditYourProfileLinkPresent(){
		//
		return false;
	}
	
	public boolean isViewYourPublicProfileLinkPresent(){
		//
		return false;
	}
	

//	
//	public void clickMyOk(){
//		
//	}


}
