package BlaBlaCarProjectB4.testScripts.common.capArea;

public class VerifyCapAreaMessageIcon {

}
