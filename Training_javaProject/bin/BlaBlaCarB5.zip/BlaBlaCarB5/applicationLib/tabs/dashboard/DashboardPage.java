package BlaBlaCarB5.applicationLib.tabs.dashboard;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import BlaBlaCarB5.applicationLib.tabs.basetabs.BaseTabPage;

public class DashboardPage extends BaseTabPage{

	
	
	
}
