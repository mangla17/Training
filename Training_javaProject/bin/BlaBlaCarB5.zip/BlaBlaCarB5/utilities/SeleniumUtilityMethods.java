package BlaBlaCarB5.utilities;

public class SeleniumUtilityMethods {
	
	
	public  void takeScreenShotOnFail(){
		
	}
	
	public void addAttachement(){
		
	}

}
