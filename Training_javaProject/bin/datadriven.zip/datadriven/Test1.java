package datadriven;

import org.testng.annotations.Test;

public class Test1 {
	
	@Test
	public void test2(){
		
	}

}
