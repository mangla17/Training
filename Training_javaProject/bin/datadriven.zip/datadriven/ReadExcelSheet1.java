package datadriven;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class ReadExcelSheet1 {
	
	File srcFile = new File("D:\\IBM\\workspace\\RadicalSelenium\\src\\datadriven\\loginDemo.xlsx");
	
	XSSFWorkbook wb;
	XSSFSheet sheet ;
	
	
	@Test
	public void test() throws InvalidFormatException, IOException{
		
		FileInputStream fis = new FileInputStream(srcFile);
		
		
		XSSFWorkbook obj = new XSSFWorkbook(fis);
		//String sheetName = obj.getSheetAt(0).getSheetName();		
		
		XSSFSheet sheet = obj.getSheetAt(0);
		
//		String userName = sheet.getRow(0).getCell(0).getStringCellValue();
//		String pwd = sheet.getRow(0).getCell(1).getStringCellValue();
		
		
		int cnt = sheet.getLastRowNum();
		for(int i=0;i<=cnt;i++){
			String userName = sheet.getRow(i).getCell(0).getStringCellValue();
			String pwd = sheet.getRow(i).getCell(1).getStringCellValue();
		}
		
		//Read excel file
		wb = new XSSFWorkbook(fis);
		//get sheet
		sheet = wb.getSheetAt(0);
		System.out.println("sheet name = "+ sheet.getSheetName());
		
		int rowCount = sheet.getLastRowNum();
		System.out.println("Total row count = "+rowCount+1);
		
		
		for(int i=0;i<rowCount;i++){
			String data0 = sheet.getRow(i).getCell(0).getStringCellValue();
			System.out.println("Excel data "+data0);
		}
		
		wb.close();
		
	}
	
	
	
	public String getCellData(int sheetNumber, int row, int column){
		
		sheet =wb.getSheetAt(sheetNumber);
		String data0 = sheet.getRow(row).getCell(column).getStringCellValue();
		return data0;
	}
	
	
	

}
