package MyBlaBlaCarB3.testScripts.common;

public class MyCapAreaAcript1 {

}
