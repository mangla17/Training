package MyBlaBlaCarB3.utilities;

public class TakeScreenShotUtilites {

}
