package MyBlaBlaCarB3.AppData.tabs;

public class ProfilePage {
	
	DashobardPage obj = new DashobardPage();
	
	public void clickProfileTab(){
		obj.clickTab("xpath");;
	}

}
