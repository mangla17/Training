package MyBlaBlaCarB3.AppData.common;

public class BasePage {

}
