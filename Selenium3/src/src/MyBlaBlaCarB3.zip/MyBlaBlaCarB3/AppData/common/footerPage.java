package liveProjectBlaBlaCar.common;

public class footerPage extends BasePage {

}
