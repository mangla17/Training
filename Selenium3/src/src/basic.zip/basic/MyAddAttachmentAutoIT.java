package basic;

import java.awt.AWTException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class MyAddAttachmentAutoIT {
	
	@Test
	public void addAttachment() throws InterruptedException, AWTException{
		
		WebDriver driver = new FirefoxDriver();
		driver.get("http://www.2shared.com");
		driver.manage().window().maximize();
		
		Thread.sleep(5000);
		driver.findElement(By.id("upField")).sendKeys("D:\\TrainingContent\\URLs.txt");
		
		Thread.sleep(5000);
//		Robot myRobot = new Robot();
//		myRobot.keyPress(KeyEvent.VK_ESCAPE);
	}

}
