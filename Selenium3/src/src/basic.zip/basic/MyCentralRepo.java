package basic;

public class MyCentralRepo {
	
	
	static String projectLoc ="//a[contains(text(),'Projects')]";
	static String downloadLoc ="//a[contains(text(),'Download')]";
	static String documentationLoc ="//a[contains(text(),'Documentation')]";
	static String supportLoc ="//a[contains(text(),'Support')]";
	static String aboutLoc ="//a[contains(text(),'About')]";
	

}
