package basic;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class AlertAndConfirmation {
	
	@Test
	public static void test() throws InterruptedException{
		
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();
		driver.get("http://www.destinationqa.com/aut/AlertsPopups.html");
		Thread.sleep(4000);
		
		//Alert
		driver.findElement(By.xpath("//input[@id='btnAlert']")).click();
		Thread.sleep(2000);
		String s = driver.switchTo().alert().getText();
		driver.switchTo().alert().accept();
		System.out.println("===" + s);
		boolean result =s.equals("I'm blocking!");
		Assert.assertTrue(result, "Message alert wrong");
		Thread.sleep(2000);
		
		//Confirmation
		driver.findElement(By.xpath("//input[@id='btnConfirm']")).click();
		Thread.sleep(2000);
		Alert myConfi = driver.switchTo().alert();
		String s1 = myConfi.getText();
		System.out.println("===" + s1);
		Assert.assertTrue(s1.equals("Chose an option."), "Message confirmation wrong");
		myConfi.dismiss();
		
		
		
	}

}
