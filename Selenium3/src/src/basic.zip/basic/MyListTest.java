package basic;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class MyListTest {
	
	
	
	
	
	private String getContryLocatior(String contryName){
		String mycontry = "//ul/li[contains(text(),'"+contryName+"')]";
		return mycontry;
	}
	
	@Test
	public void test() throws InterruptedException{
		WebDriver driver = new FirefoxDriver();
		driver.get("http://demos.telerik.com/aspnet-ajax/listbox/examples/overview/defaultvb.aspx");
		Thread.sleep(4000);
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath(getContryLocatior("Brazil"))).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@title='To Right']/span")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath(getContryLocatior("Canada"))).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@title='To Right']/span")).click();
		
		
		
		
		
		
//		driver.findElement(By.xpath("//div[@class='rlbGroup']/ul/li[contains(text(),'Canada')]")).click();
//		Thread.sleep(4000);
	}

}
