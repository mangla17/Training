package basic;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

public class MyTest {
	
	public void test1(){
		
		WebDriver driver = new HtmlUnitDriver();
		
	}

}
