package basic;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import advanced.MyScreenShot;

public class MyButton {
	
	
	WebDriver driver;
		@Test
		public void test() throws InterruptedException, IOException{
			
			//try{
				driver = new FirefoxDriver();
				driver.get("https://demos.telerik.com/aspnet-ajax/button/examples/overview/defaultvb.aspx");
				Thread.sleep(4000);
				driver.manage().window().maximize();
				By myBy = By.xpath("//button[@id='ctl00_ContentPlaceholder1_btnStandard']/span");
				driver.findElement(myBy).click();;
				Thread.sleep(4000);
				driver.close();
				driver.quit();
//			}catch(Exception e){
//				MyScreenShotUtil.takeAnilsScreenShot(driver);
//			}
		}
}
