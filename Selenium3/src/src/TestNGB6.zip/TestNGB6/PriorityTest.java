package TestNGB6;

import org.testng.annotations.Test;

public class PriorityTest {
	
	
	@Test
	public void myTest1(){
		System.out.println("I am in test 1");
	}
	
	@Test(priority=3)
	public void myTest2(){
		System.out.println("I am in test 2");
	}
	
	@Test(priority=-1)
	public void zzz(){
		System.out.println("I am in test 2");
	}

}
