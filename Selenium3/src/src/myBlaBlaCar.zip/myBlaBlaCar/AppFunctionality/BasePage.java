package myBlaBlaCar.AppFunctionality;

public class BasePage {

}
