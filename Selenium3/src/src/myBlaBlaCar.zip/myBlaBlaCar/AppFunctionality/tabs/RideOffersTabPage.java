package myBlaBlaCar.AppFunctionality.tabs;

public class RideOffersTabPage {

}
