package myBlaBlaCar.AppFunctionality.tabs;

import myBlaBlaCar.AppFunctionality.BaseTabPage;

public class ProfileTabPage extends BaseTabPage{

}
