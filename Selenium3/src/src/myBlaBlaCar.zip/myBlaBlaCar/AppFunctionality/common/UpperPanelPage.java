package myBlaBlaCar.AppFunctionality.common;

import myBlaBlaCar.AppFunctionality.BasePage;

public class UpperPanelPage extends BasePage{

}
