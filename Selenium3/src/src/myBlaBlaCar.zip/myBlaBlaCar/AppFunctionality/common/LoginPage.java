package myBlaBlaCar.AppFunctionality.common;

public class LoginPage {

}
