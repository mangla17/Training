package myBlaBlaCar.utilites;

import org.openqa.selenium.WebDriver;

public class SeleniumUtitlity {
	
	public void getScreenShot(WebDriver driver, String path){
		
	}
	
	public void addAttachment(WebDriver driver, String path){
		
	}

	public void downloadFile(WebDriver driver, String path){
	
	}
	

}
